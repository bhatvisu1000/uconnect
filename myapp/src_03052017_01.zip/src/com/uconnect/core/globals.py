id:1001, weight: {101} details:{}
id:1002, details:{}
..
..
..
id:2000

