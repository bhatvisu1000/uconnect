from com.uconnect.core.singleton import Singleton
import json, os, sys, logging
import com.uconnect.utility.ucLogging
import com.uconnect.core.error

myLogger = logging.getLogger('uConnect')

@Singleton
class Environment(object):
  '''
  This is initialization class, this is the first class excuted during initialization process
  '''
  def __init__(self):
    ''' 
        Description:    Initialize/read/populates following components
                        1. Global Setting
                        2. Specific Environment Setting
                        3. Facroty Metadata
                        4. Zipcode
                        5. Defaults value
        argEnvType:     N/A
        usage:          <called internally during instantiation process>
        Return:         <N/A>
    '''

    ''' building core path - globals.json'''
    
    myModuleLogger = logging.getLogger('uConnect.'+__name__+'.Environment')

    myModuleLogger.info("Initializing Environment ...")

    self.uconnectHome = os.environ['UCONNECT_HOME']
    self.configLoc = os.path.join(self.uconnectHome,'config')
    self.myGlobalFile = os.path.join(self.configLoc,'globals.json')

    ''' Global Settings - globals.json'''
    try:
      # ensure config file exists
      # globals.json
      if not (os.path.isfile(self.myGlobalFile)):
        raise com.uconnect.core.error.MissingConfigFile("GlobalFile [{globalFile}] is missing !!!".format(globalFile=self.myGlobalFile))

      myModuleLogger.info("Reading global configuration file [{globalFile}] ".format(globalFile=self.myGlobalFile))
      self.globalSettings = json.loads(open(self.myGlobalFile).read())

      # ensure globalsetting has value
      if not self.globalSettings: 
        raise com.uconnect.core.error.BootStrapError("GlobalSettings dictionary is empty")

    except com.uconnect.core.error.MissingConfigFile as error:
        myModuleLogger.error("MissingConfigFile Error, [{error}]".format(error=error.errorMsg))
        raise error 
    except com.uconnect.core.error.BootStrapError as error:
        myModuleLogger.error("BootStrapError, [{error}]".format(error=error.errorMsg))
        raise error     
    except ValueError as error:
       myModuleLogger.error("Error, loading global file [{globalFile}] (value error) ".format(globalFile=self.myGlobalFile))
       raise error
    except Exception as error:
       myModuleLogger.error("Error, an error occurred [{error}]".format(error=error.message))
       raise error

    ''' Building Infra/FactoryMetadata file with path '''

    self.infraFile = self.globalSettings['Infra']
    self.factoryMetaFile = self.globalSettings['Factory']
    self.zipCodeFile = self.globalSettings['ZipCode']
    self.defaultsFile = self.globalSettings['Defaults']

    self.myInfraFile = os.path.join(self.configLoc,self.infraFile)
    self.myFactoryMetaFile = os.path.join(self.configLoc,self.factoryMetaFile)
    self.myZipCodeFile = os.path.join(self.configLoc,self.zipCodeFile)
    self.myDefaultsFile = os.path.join(self.configLoc,self.defaultsFile)
    
    ''' Infra settings - infra.json '''
    try:
      # ensure config file exists
      # infra.json
      if not (os.path.isfile(self.myInfraFile)):
        raise com.uconnect.core.error.MissingConfigFile("Infra file [{infraFile}] is missing !!!".format(infraFile=self.myInfraFile))

      self.myEnvDetailResult = {}
      ''' Reading infra file '''
      myModuleLogger.info("Reading infra config file [{infraFile}] ".format(infraFile=self.myInfraFile)) 
      self.myInfra = json.loads(open(self.myInfraFile).read())
    
      # check if myInfra dictionary is empty, raise error

      if not self.myInfra: 
        raise com.uconnect.core.error.BootStrapError("InfraSetting dictionary is empty")

    except com.uconnect.core.error.MissingConfigFile as error:
        myModuleLogger.error("MissingConfigFile Error, [{error}]".format(error=error.errorMsg))
        raise error 
    except com.uconnect.core.error.BootStrapError as error:
        myModuleLogger.error("BootStrapError, [{error}]".format(error=error.errorMsg))
        raise error     
    except ValueError as error:
       myModuleLogger.error("Error, loading Infra file [{infraFile}] (value error) ".format(infraFile=self.myInfraFile))
       raise error
    except Exception as error:
       myModuleLogger.error("Error, an error occurred [{error}]".format(error=error.message))
       raise error

    ''' factory metadata '''
    try:
      # ensure config file exists
      # infra.json
      if not (os.path.isfile(self.myFactoryMetaFile)):
        raise com.uconnect.core.error.MissingConfigFile("FactoryMetada File [{factoryFile}] is missing !!!".format(factoryFile=self.myFactoryMetaFile))

      myModuleLogger.info("Reading factory json file [{factoryFile}] ".format(factoryFile=self.factoryMetaFile)) 
      self.myFactoryMetaData = json.loads(open(self.myFactoryMetaFile).read())
    
      # check if factory metadata dictionary is empty after loading data, raise error

      if not self.myFactoryMetaData: 
        raise com.uconnect.core.error.BootStrapError("FactoryMetada dictionary is empty")

    except com.uconnect.core.error.MissingConfigFile as error:
        myModuleLogger.error("MissingConfigFile Error, [{error}]".format(error=error.errorMsg))
        raise error 
    except com.uconnect.core.error.BootStrapError as error:
        myModuleLogger.error("BootStrapError, [{error}]".format(error=error.errorMsg))
        raise error     
    except ValueError as error:
       myModuleLogger.error("Error, loading Factory Metadata file [{factoryFile}] (value error) ".format(factoryFile=self.factoryMetaFile))
       raise error
    except Exception as error:
       myModuleLogger.error("Error, an error occurred [{error}]".format(error=error.message))
       raise error

    ''' Loading zipcode '''
    try:
      # ensure config file exists
      # zipcode.json
      if not (os.path.isfile(self.myZipCodeFile)):
        raise com.uconnect.core.error.MissingConfigFile("Zipcode File [{zipCodeFile}] is missing !!!".format(zipCodeFile=self.myZipCodeFile))

      myModuleLogger.info("Reading zipcode json file [{myZipFile}] ".format(myZipFile=self.myZipCodeFile))
      self.myZipCodeData = json.loads(open(self.myZipCodeFile).read())
    
      # check if zipcode dictionary is empty after loading data, raise error

      if not self.myZipCodeData: 
        raise com.uconnect.core.error.BootStrapError("ZipCode dictionary is empty")

    except com.uconnect.core.error.MissingConfigFile as error:
        myModuleLogger.error("MissingConfigFile Error, [{error}]".format(error=error.errorMsg))
        raise error 
    except com.uconnect.core.error.BootStrapError as error:
        myModuleLogger.error("BootStrapError, [{error}]".format(error=error.errorMsg))
        raise error     
    except ValueError as error:
       myModuleLogger.error("Error, loading Zipcode file [{zipcCodeFile}] (value error) ".format(zipcCodeFile=self.myZipCodeFile))
       raise error
    except Exception as error:
       myModuleLogger.error("Error, an error occurred [{error}]".format(error=error.message))
       raise

    ''' Loading Defaults value from defaults.json '''
    try:
      # ensure config file exists
      # defaults.json.json
      if not (os.path.isfile(self.myDefaultsFile)):
        raise com.uconnect.core.error.MissingConfigFile("Defaults File [{defaultsFile}] is missing !!!".format(defaultsFile=self.myDefaultsFile))

      myModuleLogger.info("Reading defaults json file [{defaultsFile}] ".format(defaultsFile=self.myDefaultsFile))
      self.myDefaultsData = json.loads(open(self.myDefaultsFile).read())
    
      # check if defaults dictionary is empty after loading data, raise error

      if not self.myDefaultsData: 
        raise com.uconnect.core.error.BootStrapError("Defaults dictionary is empty")

    except com.uconnect.core.error.MissingConfigFile as error:
        myModuleLogger.error("MissingConfigFile Error, [{error}]".format(error=error.errorMsg))
        raise error 
    except com.uconnect.core.error.BootStrapError as error:
        myModuleLogger.error("BootStrapError, [{error}]".format(error=error.errorMsg))
        raise error     
    except ValueError as error:
       myModuleLogger.error("Error, loading Defaults file [{defaultsFile}] (value error) ".format(defaultsFile=self.myDefaultsFile))
       raise error
    except Exception as error:
       myModuleLogger.error("Error, an error occurred [{error}]".format(error=error.message))
       raise

    ''' initializing other variables '''

    self.maxPageSize = int(self.globalSettings['maxPageSize'])

  def getEnvironmentDetails(self, argEnvType):
    ''' 
        Description:    Returns environment details for a given environment 'Dev/Prod'
        argEnvType:     Environment type 
        usage:          <getEnvironmentDetails(<envrionment type>)
        Return:         Dictonary
    '''
    myModuleLogger = logging.getLogger('uConnect.'+__name__+'.Environment')

    ''' will build dictionary from globals and infra dictionary for a given env type '''
    
    self.myEnvDetailResult = self.globalSettings

    myModuleLogger.info("Preparing environment details for [{myEnvironment}] ".format(myEnvironment=argEnvType)) 
    
    self.myEnvDetailResult.update(self.myInfra[argEnvType])

    myModuleLogger.debug("Environent details for [{myEnvironment}] is [{myEnvDetails}] ".format(myEnvironment=argEnvType, myEnvDetails=self.myEnvDetailResult)) 
    
    return self.myEnvDetailResult


'''
if __name__ == "__main__":
  print "Reading global settings"
  
  myEnv = Environment()
  #print globalSettings['Environment']
  myEnvDetails = myEnv.getEnvironmentDetails(myEnv.globalSettings['Environment'])
  print myEnvDetails
'''