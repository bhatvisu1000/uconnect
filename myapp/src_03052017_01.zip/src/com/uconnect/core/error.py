#from com.uconnect.core.singleton import Singleton

class ucException(Exception):
    def __init__(self,errorMsg):
        self.errorMsg = errorMsg
    def __str__(self):
        return repr(self.errorMsg)

#@Singleton
class MissingConfigFile(ucException):
    pass

#@Singleton
class MissingConfigFile(Exception):
    pass

#@Singleton
class MissingArgumentValue(ucException):
    pass

#@Singleton
class MissingConfigFile(ucException):
    pass

#@Singleton
class BootStrapError(ucException):
    pass