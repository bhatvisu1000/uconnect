from com.uconnect.core.dbconnection import ConnectionBuilder
from com.uconnect.core.infra import Environment
from com.uconnect.core.singleton import Singleton
from com.uconnect.utility.ucUtility import Utility
from com.uconnect.utility.ucLogging import logging
import com.uconnect.core.error

#from com.uconnect.utility.mongoDbUtility import MongoDbUtility



# lets the parent logger from config file
myLogger = logging.getLogger('uConnect')

@Singleton
class MongoDB(object):
    def __init__(self):
        ''' Intialization method -- Private
        Instantiating all methods & logger needed for this module
        '''
        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MongoDB')
        myModuleLogger.debug("initializing ...")

        self.myConnectionBuilder = ConnectionBuilder()
        self.myConnection = self.myConnectionBuilder.buildConnection("MongoDB")
        self.myEnvironment = Environment.Instance()
        self.myPageSize = self.myEnvironment.maxPageSize
        
        myModuleLogger.debug("Initialization details: myConnection[{myConn}], myPageSize[{myPageSize}]".format(myConn=self.myConnection, myPageSize=self.myPageSize))
        myModuleLogger.debug("initialization completed")

        ## validate all the collections

    def __getRequestSummary(self, argCollection, argCriteria, argCurPage = None):
        
        ''' 
            Description:    This method is called internally in conjunction with other method in this class
            argCollection:  Collection name
            argCriteria:    Criteria to retrieve document(s)
            argCurPage:     Current page (optional)
            usage:          <__findDocument(<coll>,<criteria>,<curPage (optional)>)
            Return:         Dict object as request summary
        '''

        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MongoDB')

        myModuleLogger.debug("arg(s) received: collection[{col}], criteria[{criteria}], curPage[{curPage}]".
            format(col=argCollection,criteria=argCriteria,curPage=argCurPage))
 
        myDb = self.myConnection[argCollection]

        myModuleLogger.debug("myDb value after assigning collection [{col}]: [{mydb}]".format(col=argCollection,mydb=myDb))

        myTotDocuments = myDb.find(argCriteria).count()
        myTotPages = myTotDocuments / self.myPageSize 

        summaryResult = {"TotalDocuments":myTotDocuments,"TotalPages":myTotPages,"CurrentPage":argCurPage, "PageSize":self.myPageSize,
                         "Displaying": str(argCurPage * self.myPageSize) + " to " }

        myModuleLogger.debug("TotDoc [{totdoc}], TotPages [{totpage}]".format(totdoc=myTotDocuments,totpage=myTotPages))
        myModuleLogger.debug("Summary Result [{summary}]".format(summary=summaryResult))
        
        return summaryResult

    def __updateKeyValue(self, argCollection, argDictDocument):
        
        ''' 
            Description:    Update key in dictDocument for a given collection, this is a private method
            argCollection:  Collection name
            argDictDocument:Dict documents
            usage:          <__updateKeyValue(<coll>,<DictDocument>)
            Return:         Dictionary object
        '''
        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MongoDB')

        myModuleLogger.debug("arg(s) received: collection[{col}], dictDoc[{dictDoc}]".
            format(col=argCollection,dictDoc=argDictDocument))
 
        ##myDb = self.myConnection

        myModuleLogger.debug("Connection to be used [{conn}]".format(conn=self.myConnection))

        if len(argDictDocument) == 0:
            myModuleLogger.error("Dict document argument passed is empty [{dict}]".format(dict=argDictDocument))
            raise EmptyArg
        
        myKeyValue = int(self.myConnection.system_js.getNextSequence(argCollection))

        if myKeyValue == None:
            myModuleLogger.error("Null Key Value found for collection [{coll}]".format(coll=argCollection))
            raise NullKeyValue

        # we need to use repr to make value presented as string character
        argDictDocument.update({"_id":repr(myKeyValue)})            
        myModuleLogger.debug("Results: dict document, after updating key value [{dict}]".format(dict=argDictDocument))
        
        return argDictDocument

    def findTotDocuments(self, argCollection, argCriteria = None):
        
        ''' 
            Description:    Find document from a collection without any paging and sort
            argCollection:  Collection name
            argCriteria:    Criteria to retrieve document(s)
            argProjection:  Column which need to be projected/returned
            argFindOne:     Find only one document 
            usage:          <findDocument(<coll>,<criteria>,<projection>, <True/False>)
            Return:         Number (total documents)
        '''
        
        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MongoDB')
        myModuleLogger.debug("arg(s) received: collection[{col}], criteria[{criteria}]".
            format(col=argCollection,criteria=argCriteria))
        
        #myModuleLogger.debug("checking if collection [{coll}] exists in db [{db}]".format(coll=argCollection))

        myDb = self.myConnection[argCollection]

        myModuleLogger.debug("myDb value after assigning collection [{col}]: [{mydb}]".format(col=argCollection,mydb=myDb))        
        myModuleLogger.debug("connection [{conn}] will be used to get this member information".format(conn=myDb))        

        myTotDocuments = myDb.find(argCriteria).count()

        myModuleLogger.debug("Total Documents [{totDocuments}]".format(totDocuments=myTotDocuments))
        ## need to find type of data retunned and then use for x in to put it in dict
        myModuleLogger.debug("completed, returning value")

        return myTotDocuments

    def findDocument(self, argCollection, argCriteria, argProjection = None, argFindOne = False):
        
        ''' 
            Description:    Find document from a collection without any paging and sort
            argCollection:  Collection name
            argCriteria:    Criteria to retrieve document(s)
            argProjection:  Column which need to be projected/returned
            argFindOne:     Find only one document 
            usage:          <findDocument(<coll>,<criteria>,<projection>, <True/False>)
            Return:         List
        '''
        
        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MongoDB')
        myModuleLogger.debug("arg(s) received: collection[{col}], criteria[{criteria}], projection[{proj}], findOne[{findone}]".
            format(col=argCollection,criteria=argCriteria, proj=argProjection,findone=argFindOne))
        
        #myModuleLogger.debug("checking if collection [{coll}] exists in db [{db}]".format(coll=argCollection))

        myDb = self.myConnection[argCollection]
        myResults = []

        if len(argProjection) == 0: argProjection = None

        myModuleLogger.debug("myDb value after assigning collection [{col}]: [{mydb}]".format(col=argCollection,mydb=myDb))        
        myModuleLogger.debug("connection [{conn}] will be used to get this member information".format(conn=myDb))        

        myModuleLogger.debug("value(s) used for finding document: collection[{col}], criteria[{criteria}], projection[{proj}], findOne[{findone}]".
            format(col=argCollection,criteria=argCriteria, proj=argProjection,findone=argFindOne))

        if argFindOne:
            myResults =  myDb.find_one(argCriteria,argProjection)
            if (myResults == None): print("Null Result value")
            #myResults =  myDb.find_one(argCriteria)
        else:
            for data in myDb.find(argCriteria,argProjection): myResults.append(data)

        myModuleLogger.debug("Document [{data}] type[{type}] ".format(data=myResults, type=type(myResults)))
        #myModuleLogger.debug("Document Data [{data}]".format(data=myResults))
        ## need to find type of data retunned and then use for x in to put it in dict
        myModuleLogger.debug("completed, returning document")

        return myResults

    def findAllDocuments4Page(self, argCollection, argCriteria = None, argProjection = None, argPage = 0, argSort = None):

        ''' 
            Description:    Find all documents from a collection with paging and sort
            argCollection:  Collection name
            argCriteria:    Criteria to retrieve document(s)
            argProjection:  Column which need to be projected/returned
            argPage:        Page# which need to be returned            
            argSort:        Sort arguments, defaults to none 
            usage:          <findDocument(<coll>,<criteria>,<projection>, <True/False>)
            Return:         List
        '''

        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MongoDB')
        myModuleLogger.debug("args received: collection[{coll}], page[{page}], sort[{sort}]".format(coll=argCollection, page=argPage,sort=argSort))

        myDb = self.myConnection[argCollection]
        myResults = []

        if len(argProjection) == 0: argProjection = None

        skipPage = int(argPage) * (self.myPageSize)

        if (argSort == None): argSort = {"_id":1}

        myResults.append(self.__getRequestSummary(argCollection, argCriteria, int(argPage)))
        for data in myDb.find(argCriteria).skip(skipPage).limit(self.myPageSize).sort(argSort):
            myResults.append(data)

        myModuleLogger.debug("completed, returning document(s)")

        return myResults

    
    def InsertOneDoc(self, argCollection, argDocument):
        ''' 
            Description:    Insert a document in a given collection, _ID value will be overwritten
            argCollection:  Collection name
            argDocument:    Document as dict need to be inserted
            usage:          ( InsertOneDoc(<coll><document as dict>)
            <<
                we should incorporate insert many and one in single method
                need to check if multiple doc is passed
                if mutliptle doc is passed we need to generate the key for each document
                may be for future? not right now
            >>
            Return:         Dictionary (_id, status)
        '''

        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MongoDB')
        myModuleLogger.debug("args received: collection[{coll}], document[{docdict}]".format(coll=argCollection, docdict=argDocument))

        ''' call validation method to see if passed collection is a valid collection '''
        try:
            myDb = self.myConnection[argCollection]
        except Exception as error:
            myModuleLogger.error("Can not set collection to [{coll}], error[{err}]".format(coll=argCollection,err=error))
            raise e
        finally:
            pass
        
        ''' we need key to be generated for this collection '''
        myDictDocument = self.__updateKeyValue(argCollection, argDocument)

        myInsertOneResult = myDb.insert_one(myDictDocument)

        myModuleLogger.debug("requested document inserted with [{_id}, {status}]".format(_id=myInsertOneResult.inserted_id, status=myInsertOneResult.acknowledged))
        myresult = {"_id":myInsertOneResult.inserted_id,"status":myInsertOneResult.acknowledged}
        
        return myresult

    def InsertManyDoc(self, argCollection, argDocument):
        ''' 
            Description:    Insert a document in a given collection, _ID value will be overwritten
            argCollection:  Collection name
            argDocument:    Document as dict need to be inserted
            usage:          ( InsertOneDoc(<coll><document as dict>)
            Return:         (_id,status)
        '''

        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MongoDB')
        myModuleLogger.debug("args received: collection[{coll}], document[{docdict}]".format(coll=argCollection, docdict=argDocument))

        try:
            myDb = self.myConnection[argCollection]
        except Exception as error:
            myModuleLogger.error("Can not set collection to [{coll}], error[{err}]".format(coll=argCollection,err=error))
            raise error
        finally:
            return 'error'
        
        ''' we need key to be generated for this collection '''
        myDictDocument = self.__updateKeyValue(argCollection, argDocument)
        
        ''' check how many documents are passed, if only one document passed, route the call to Insert one'''

        myInsertManyResult = myDb.insert_one(myDictDocument)

        myModuleLogger.debug("requested document inserted with [{_id}, {status}]".format(_id=myInsertManyResult.inserted_id, status=myInsertOneResult.acknowledged))
        myresult = {"_id":myInsertManyResult.inserted_id,"status":myInsertManyResult.acknowledged}
        return myresult

    def UpdateDoc(self, argCollection, argCriteria, argUpdateValue, argUpdateOperator = 'set', argUpdateMany = False):
        ''' 
            Description:    Insert a document in a given collection, _ID value will be overwritten
            argCollection:  Collection name
            argDocument:    Document as dict need to be inserted
            usage:          ( InsertOneDoc(<coll><document as dict>)
            Return:         (_id,status)
        '''

        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MongoDB')
        myModuleLogger.debug("args received: collection[{coll}], document[{docdict}]".format(coll=argCollection, docdict=argDocument))

        try:
            myDb = self.myConnection[argCollection]
        except Exception as error:
            myModuleLogger.error("Can not set collection to [{coll}], error[{err}]".format(coll=argCollection,err=error))
            raise error
        finally:
            pass
        
        if (argUpdateMany):
            myDbUpdate = myDb.update_one
        else:
            myDbUpdate = myDb.update_many
        
        if (argUpdateOperator == 'set'):
            updOperator='$set'
        else:
            updOperator='$inc'

        try:
            myUpdatedResult = myDbUpdate(argCriteria,{updOperator : argUpdateValue})
        except Exception as error:
            myModuleLogger.error("could not perform update request, error stack[{errStack}]".format(errStack=error))
            raise error
        finally:
            return "error"

        myModuleLogger.debug("requested document updated with [{_id}, {status}]".format(_id=myUpdatedResult.updated_id, status=myUpdatedResult.acknowledged))
        myresult = {"_id":myUpdatedResult.updated_id,"status":myUpdatedResult.acknowledged}
        return myresult

if ( __name__ == "__main__" ):
    print "In main, I am being called to perform some task"
    myResult = ""
    myDocDB = MongoDB()
    myResult = myDocDB.getADocument('MEMBER',"MEM201981") 
    #myMemberDB.getMemberDetails("MEM201981",myResult)
    #myMemberDB.getMemberDetails("MEM201981",self.myResult)
    #print len(myMemberDB.memberResults)
    #list(myMemberDB.memberResults);
    totalRecords = myResult.count()
    print "Total %s" % totalRecords ," member found"
    for x in myResult:
        print x
