import os, sys, json
from com.uconnect.core.singleton import Singleton
from com.uconnect.utility.ucLogging import logging

myLogger = logging.getLogger('uConnect')

@Singleton
class Utility(object):

    def __init__(self):
        pass

    def isDict(self, argValue):
        try:
            if isinstance(argValue,dict): 
                return True
            else:
                return False
        except Exception as error:
            return False
        finally:
            pass

    def isList(self, argValue):
        try:
            if isinstance(argValue,list): 
                return True
            else:
                return False
        except Exception as error:
            return False
        finally:
            pass
            
    def findKeyInListDict(self, argList, argKey, argVal):
        return [i for i, x in enumerate(argList) if (argKey in x) and ( x[argKey] == argVal ) ]
    def valBPSArguments(self, argRequest):
        ''' 
            Description:    Validate argument passed as json/dict to BPS processes, returns True or False
            argReuest:      Dictionary object must be in following format
                            {"Request":
                                {"Header":
                                    {"ScreenId":"2001","ActionId":"100","Page":""},
                                 "MainArg":
                                    {"MemberId":"100001"},
                                 "Auth":
                                    {}
                                }
                            }            
            usage:          ( valBPSArguments(<dictionary object>)
        '''
        print(type(argRequest))
        print(argRequest)
        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.Utility')
        myModuleLogger.debug("validating dict argument ")
        if (len(argRequest['Request']['Header']) == 0 ):
            myModuleLogger.ERROR("Header key is empty [{arg}], expecting screenid, acrtion id (page# optional) !!!".format(arg=argRequest))
            return False
        elif (len(argRequest['Request']['MainArg']) == 0 ):
            myModuleLogger.ERROR("MainArg key is empty [{arg}], expecting nonempty value) !!!".format(arg=argRequest))
            return False
        elif (len(argRequest['Request']['MainArg']) == 0 ):
            myModuleLogger.ERROR("Auth key is [{arg}] empty, expecting authorizartion information !!!) [{arg}]".format(arg=argRequest))
            return False

        return True

