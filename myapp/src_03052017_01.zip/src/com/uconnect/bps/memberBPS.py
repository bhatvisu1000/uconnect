import json,logging, com.uconnect.utility.ucLogging, com.uconnect.core.error

from com.uconnect.core.infra import Environment
from com.uconnect.core.singleton import Singleton
from com.uconnect.bps.factory import Factory
from com.uconnect.db.mongodb import MongoDB
from com.uconnect.utility.ucUtility import Utility

myLogger = logging.getLogger('uConnect')

@Singleton
class MemberBPS(object):
    ''' 
    Member BPS class, called from factory method
    '''
    def __init__(self):
        ''' 
            Description:    Initialization internal method, called internally
            usage:          Called internally
            Return:         N/A
        '''        
        self.myEnvironment = Environment.Instance()
        self.myFactory = Factory.Instance()
        self.myUtility = Utility.Instance()
        self.myMongoDb = MongoDB.Instance()

    def findAMemberDetail(self,argRequest):
        ''' 
            Description:    Find a member details
            argRequest:     Json/Dict; Following key name is expected in this dict/json object
                            {'Request': 
                                {'Header':{ScreenId':'','ActionId':'',Page:},
                                {'MainArg': {'Criteria':{},'Projection':{},'FindOne':True/False}}
                            }
            usage:          <findAMemberDetail(<argReqJsonDict>)
            Return:         Json object
        '''
        # we need to check which arguments are passed; valid argument is Phone/Email/LastName + FirstName

        print (argRequest)
        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MemberBPS')
        myModuleLogger.info("validating dict argument [{arg}]".format(arg=argRequest))
        myCollection = 'Member'

        # raise an user defined exception here
        try:
            myArgValidation = self.myUtility.valBPSArguments(argRequest)
            if not (myArgValidation):
                raise com.uconnect.core.error.MissingArgumentValue
        except com.uconnect.core.error.MissingArgumentValue:
            myModuleLogger.error("Invalid argument passed [{arg}]".format(arg=argRequest))
            raise
        except Exception as e:
            myModuleLogger.error("Invalid argument passed [{arg}]".format(arg=argRequest))
            raise

        myModuleLogger.info("Finding a member details [{arg}]".format(arg=argRequest['Request']['MainArg']))
        myCriteria = argRequest['Request']['MainArg']['Criteria']
        #myProjection = argRequest['Request']['MainArg']['Projection']
        myFindOne = argRequest['Request']['MainArg']['FindOne']

        '''
        overriding myprojection value
        '''
        
        myProjection={"Main.LastName":1,"Main.FirstName":1,
                      "Address.Street":1,"Address.City":1,"Address.State":1,
                      "Contact.Email":1,"Contact:Mobile":1}
        myResult = self.myMongoDb.findDocument(myCollection, myCriteria,myProjection,myFindOne)
        return myResult

    def findMembers(self,argRequest):
        pass
    def createAMember(self,argRequest):
        ''' 
            Description:    Create a member
            argRequest:     Json/Dict; Following key name is expected in this dict/json object
                            {'Request': 
                                {'Header':{ScreenId':'','ActionId':'',Page:},
                                {'MainArg': {<Member data 'Main','Address','Contact'>}}
                            }
                            We will add 'BusyHours', BusyDays' block from default value
            usage:          <findAMemberDetail(<argReqJsonDict>)
            Return:         Json object
        '''

        myModuleLogger = logging.getLogger('uConnect.' +str(__name__) + '.MemberBPS')
        myModuleLogger.info("validating dict argument [{arg}]".format(arg = argRequest))
        myCollection = 'Member'

        myArgValidation = self.myUtility.valBPSArguments(argRequest)
        try:
            myArgValidation = self.myUtility.valBPSArguments(argRequest)
            if not (myArgValidation):
                raise com.uconnect.core.error.MissingArgumentValue
        except com.uconnect.core.error.MissingArgumentValue as err:
            myModuleLogger.error("Invalid argument passed [{arg}]".format(arg=argRequest))
            raise
        except Exception as err:
            myModuleLogger.error("Error [{err}] occurred while validating argument [{arg}".format(err=err, arg=argRequest))
            myModuleLogger.error("Invalid argument passed [{error}]".format(error=err.errorMsg))
            raise

        myModuleLogger.info("Inserting document")
        myArgumentData = argRequest['Request']['MainArg']
        myResult =  self.myMongoDb.InsertOneDoc(myCollection, myArgumentData)
        myModuleLogger.info("Call completed, result[{result}]".format(result=myResult))
        # need to update json and pass as an argument to get the member details
        # argRequest.update({'MainArg':{'Criteria':{'_id':myResult['_id']},'Projection':{}}})
        myCriteria = {'_id':myResult['_id']}
        myProjection = {}
        myFindOne = True
        myResult = self.myMongoDb.findDocument(myCollection, myCriteria,myProjection,myFindOne)

        return myResult

    def createAMemGroup(self,argRequest):
        pass
    def linkAMember2Member(self,argRequest):
        pass    
    def linkAMember2Group(self,argRequest):
        pass    
    def favoriteMember(self,argRequest):
        pass    
    def favoriteGroup(self,argRequest):
        pass    
    def blockMember(self,argRequest):
        pass    
    def blockGroup(self,argRequest):
        pass    
    def updateContacts(self,argRequest):
        pass    
    def updateAddress(self,argRequest):
        pass    
    def updateBusyHrs(self,argRequest):
        pass    
    def updateVacation(self,argRequest):
        pass    
